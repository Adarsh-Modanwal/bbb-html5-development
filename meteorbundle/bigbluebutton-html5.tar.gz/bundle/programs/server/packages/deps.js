(function () {

/* Imports */
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;



/* Exports */
Package._define("deps", {
  Tracker: Tracker,
  Deps: Deps
});

})();
